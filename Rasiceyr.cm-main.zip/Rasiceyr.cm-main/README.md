file contains little bit info about rasicaseyr post colonization and after colonization.
